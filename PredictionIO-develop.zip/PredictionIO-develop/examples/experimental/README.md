**NOTE:** This *$PIO_HOME/examples/experimental/* directory contains experimental examples which may not be compatible with the latest stable PredictionIO release.

Please refer to *$PIO_HOME/templates/* and *$PIO_HOME/examples/* for stable examples.
