---
title: How-To (E-Commerce Recommendation)
---

Here are the pages that show you how you can customize the E-Commerce Recommendation engine template.

- [Train with Rate Event](/templates/ecommercerecommendation/train-with-rate-event/)
