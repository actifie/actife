Scala API Documentation
=======================

1.  Run this command at the project's root.
    ```
    $ sbt/sbt pioUnidoc
    ```

2.  Point your web browser at `target/scala-2.10/unidoc/index.html`.
