---
title: Tutorials and Samples
---

# Engine Tutorials and Samples


## Item Recommendation

### Rails
[Building a Business Recommendation App with Rails Using Yelp Data](itemrec/rails.html)

### Python
[Building Movie Recommendation App with Sample Code](itemrec/movielens.html)

## Item Ranking

* (coming soon)

## Item Similarity

* (coming soon)
