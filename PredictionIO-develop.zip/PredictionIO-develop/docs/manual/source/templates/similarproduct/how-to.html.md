---
title: How-To  (Similar Product)
---
      
Here are the pages that show you how you can customize the Similar Product engine template. 
 
- [Multiple Events and Multiple Algorithms](/templates/similarproduct/multi-events-multi-algos)
