---
title: How-To  (Classification)
---
      
Here are the pages that show you how you can customize the Classification engine template. 
 
- [Use Alternative Algorithm](/templates/classification/add-algorithm/)
- [Read Custom Properties](/templates/classification/reading-custom-properties/)
