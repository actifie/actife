---
title: List of PredictionIO SDKs
---

## Officially Supported SDKs

* [Java & Android SDK](/sdk/java/)
* [PHP SDK](/sdk/php/)
* [Python SDK](/sdk/python/)
* [Ruby SDK](/sdk/ruby/)

## Community Powered SDKs

See the full list [here](/sdk/community/).
