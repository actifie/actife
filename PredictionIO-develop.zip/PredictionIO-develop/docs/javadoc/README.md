Java API Documentation
======================

1.  Run this command at the project's root.
    ```
    $ sbt/sbt unidoc
    ```

2.  Point your web browser at `target/javaunidoc/index.html`.
