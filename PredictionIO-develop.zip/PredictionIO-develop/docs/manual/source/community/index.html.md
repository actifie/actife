---
title: Community Page
---

## User Forum

Join our [Google Group](https://groups.google.com/forum/#!forum/predictionio-user).

## Request a Feature

Fill out the form [here](https://predictionio.uservoice.com/forums/219398-general/filters/top).

## Twitter

Follow us on Twitter [@predictionio](https://twitter.com/PredictionIO).

## Facebook Page

Like us on Facebook at [https://www.facebook.com/predictionio](https://www.facebook.com/predictionio).

## GitHub

View our code on GitHub at [https://github.com/PredictionIO](https://github.com/PredictionIO)

<iframe src="/github/?user=PredictionIO&repo=PredictionIO&type=fork&count=true&size=large" allowtransparency="true" frameborder="0" scrolling="0" width="170" height="30"></iframe>
<iframe src="/github/?user=PredictionIO&repo=PredictionIO&type=watch&count=true&size=large" allowtransparency="true" frameborder="0" scrolling="0" width="170" height="30"></iframe>
