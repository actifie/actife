---
title: Built-in Algorithm Libraries
---

An engine can virtually call any algorithm in the Algorithm class. PredictionIO currently offers native support to [Spark MLlib](http://spark.apache.org/docs/latest/mllib-guide.html) machine learning library.
It is being used by some of the engine templates in the [template gallery](http://templates.prediction.io/).

More library support will be added soon.