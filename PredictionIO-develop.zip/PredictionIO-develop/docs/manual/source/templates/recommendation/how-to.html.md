---
title: How-To  (Recommendation)
---
      
Here are the pages that show you how you can customize the Recommendation engine template. 
 
- [Read Custom Events](/templates/recommendation/reading-custom-events/)
- [Train with Implicit Preference](/templates/recommendation/training-with-implicit-preference/)
- [Customize Data Preparator](/templates/recommendation/customize-data-prep/)
- [Customize Serving](/templates/recommendation/customize-serving/)
- [Filter Recommended Items by Blacklist in Query](/templates/recommendation/blacklist-items/)
