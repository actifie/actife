---
title: Data API
---

# Adding Algorithms to a Built-in Engine

(coming soon)