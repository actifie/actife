package io.prediction.examples.friendrecommendation

class RandomModel(
  val randomThreshold: Double
) extends Serializable
