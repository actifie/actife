## TODO: update with new engine.json format and CLI! (updates pending)

## Download Data from GroupLens

Execute the following command to download MovieLens 100k to data/ml-100k/.
```
$ ./fetch.sh
```

## Tutorials

The purpose of this tutorial is to help you to get familiar with each components of the PredictionIO framework. It can be found in `docs/manual/tutorials/enginebuilders/stepbystep`.
