---
title: Narrow Page
hidden: true
---

Keep it short!