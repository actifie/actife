package io.prediction.examples.friendrecommendation

import io.prediction.controller._

class FriendRecommendationAlgoParams (
) extends Params
