---
title: Combining Multiple Algorithms
---

You can use more than one algorithm to build multiple models in an engine. The predicted results can be combined in the Serving class.

Here are some How-to examples:

* [Similar Product template - Multiple Events and Multiple Algorithms](/templates/similarproduct/multi-events-multi-algos/)


