---
title: Switching to Another Algorithm
---

Every engine template comes with default algorithm(s). To switch to another algorithm, you simply need to modify the Algorithm class.

Here are some How-to examples:

* [Classification template - switching from NaiveBayes to Random Forests](/templates/classification/add-algorithm/)
